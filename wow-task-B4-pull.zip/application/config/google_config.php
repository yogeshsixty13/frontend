<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Gautam
$config['google_client_id'] = "928066407020-57mu8pom065chbuuog9iqm4ggldcheqi.apps.googleusercontent.com";
$config['google_client_secret'] = "4qmdceCa9ONbr6aT_qCyoMiX";

//Vrunda

// $config['google_client_id'] = "453865389246-49mmkvso2fi50cssts92eie2n6f547ls.apps.googleusercontent.com";
// $config['google_client_secret'] = "xEQSeU3P6E3uUA_DrVCiESbb";
$config['google_redirect_url'] = base_url().'google-login';

